MAPTILER CLONE — MULTI-FLOOR TEST DATA

Contents:
- basement_1.png
- ground_floor.png
- floor_1.png
- floor_2.png
- floor_3.png
- manifest.json

Purpose:
Test ZIP ingestion, multi-dataset discovery, building/floor grouping, manual georeferencing,
zoom-dependent floor switching, layer visibility, floor-specific editing, workspace restoration,
and disposable workspace export/import.

Important:
These are synthetic illustrative PNG floor plans. They are intentionally NOT georeferenced.
They share approximately the same building footprint but contain floor-specific details and
small footprint offsets to help test alignment correction. Use the app's georeferencing workflow
to assign a common building footprint before testing geographic rendering. The scale bar is illustrative only.

Suggested tests:
1. Upload the ZIP and verify all five PNGs are discovered.
2. Group them under one building object.
3. Confirm each floor is a child raster layer, not a separate building.
4. Georeference the building and confirm floor rasters inherit the shared reference.
5. Zoom in/out and verify configured floor switching works in the intended direction.
6. Manually select floors and toggle visibility.
7. Transform one floor and confirm the other floors do not change.
8. Navigate away and reopen the workspace during the same session.
9. Export a disposable URL and verify the floor hierarchy and selection are restored.
